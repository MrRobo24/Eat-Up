package com.arpit.eatup.fragment

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment

import com.arpit.eatup.R
import java.util.*


class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        return view
    }


    // sorting begins
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater?.inflate(R.menu.menu_home, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val id = item?.itemId
        when(id) {
            R.id.action_sort -> {
                Collections.sort(bookInfoList, ratingComparator)
                bookInfoList.reverse()
            }
        }

        recyclerAdapter.notifyDataSetChanged()

        return super.onOptionsItemSelected(item)
    }
    //sorting ends

}
