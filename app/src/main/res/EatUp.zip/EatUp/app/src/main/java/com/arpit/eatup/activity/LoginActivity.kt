package com.arpit.eatup.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.arpit.eatup.R
import org.json.JSONObject
import java.lang.Exception

class LoginActivity : AppCompatActivity() {

    lateinit var etMobileNumber: EditText
    lateinit var etPassword: EditText
    lateinit var btnLogin: Button
    lateinit var txtForgotPassword: TextView
    lateinit var txtRegister: TextView

    lateinit var intentLogin: Intent

    lateinit var sharedPreferences: SharedPreferences
    val spFileName = "EatUp Preferences"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // getting the shared preferences
        sharedPreferences = getSharedPreferences(spFileName, Context.MODE_PRIVATE)
        // checking if the user is logged in already or not from last session
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        // intent to start the main activity
        intentLogin = Intent(this@LoginActivity, MainActivity::class.java)

        if (isLoggedIn) {
            startActivity(intentLogin)
            finish()
        }


        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtRegister = findViewById(R.id.txtRegister)


        btnLogin.setOnClickListener {
            val mobileNumber: String = etMobileNumber.text.toString()
            val password: String = etPassword.text.toString()

            // if some field is left blank
            if (mobileNumber.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                    this@LoginActivity,
                    "No field should be left blank",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                // min password length is four
                if (password?.length < 4) {
                    Toast.makeText(
                        this@LoginActivity,
                        "Minimum password length should be 4 characters!!",
                        Toast.LENGTH_LONG
                    ).show()
                } else { // everything is fine to submit
                    login(mobileNumber, password)
                }
            }
        }


        txtRegister.setOnClickListener {
            val intentRegister = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intentRegister)
            finish()
        }


    }

    fun login(mobileNumber: String, password: String) {
        val queueRequests = Volley.newRequestQueue(this@LoginActivity)
        val url = "http://13.235.250.119/v2/login/fetch_result/"
        val jsonParams = JSONObject()
        jsonParams.put("mobile_number", mobileNumber)
        jsonParams.put("password", password)

        val jsonObjectRequest =
            object : JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {

                try {
                    //fetch success boolean
                    val dataObject = it.getJSONObject("data")
                    val success = dataObject.getBoolean("success")
                    if (success) {
                        // login credentials were authenticated
                        sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
                        startActivity(intentLogin)
                        finish()
                        // SAVE USER INFORMATION TOO IN LATER STAGES

                    } else {
                        //  login credentials couldn't be authenticated
                        val errorMessage = it.getString("errorMessage")
                        Toast.makeText(
                            this@LoginActivity,
                            errorMessage,
                            Toast.LENGTH_LONG
                        ).show()
                    }

                } catch (e: Exception) {

                    Toast.makeText(
                        this@LoginActivity,
                        "Some unexpected error has occurred!!",
                        Toast.LENGTH_LONG
                    ).show()
                }


            }, Response.ErrorListener {
                Toast.makeText(
                    this@LoginActivity,
                    "Volley Error!! $it",
                    Toast.LENGTH_LONG
                ).show()

            }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-type"] = "application/json"
                    headers["token"] = "37b6ded29033b0"

                    return headers
                }

            }

        //sending the request
        queueRequests.add(jsonObjectRequest)
    }

}
